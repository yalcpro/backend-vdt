import AppError from '../utils/AppError.js'

const handleZodError = (err) => {
  const message = err.errors.map((e) => e.message).join('. ')
  return new AppError(message, 400)
}

const handleValidationError = (err) => {
  const messages = Object.values(err.errors).map((e) => e.message)
  return new AppError(messages.join('. '), 400)
}

const errorMiddleware = (err, req, res, next) => {
  let error = err

  // Log detallado en desarrollo
  if (process.env.NODE_ENV === 'development') {
    console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.error('🔥 ERROR DETECTADO')
    console.error('   📡 Ruta:  ', req.method, req.originalUrl)
    console.error('   📦 Body:  ', JSON.stringify(req.body, null, 2))
    console.error('   🧩 Error: ', err)
    console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
  } else {
    console.error(`[ERROR] ${req.method} ${req.originalUrl}: ${err.message}`)
  }

  // Transformar errores conocidos
  if (err.name === 'ZodError') {
    error = handleZodError(err)
  } else if (err.name === 'ValidationError') {
    error = handleValidationError(err)
  } else if (err.code === 11000) {
    error = new AppError('El recurso ya existe (duplicado)', 400)
  } else if (err.name === 'CastError') {
    error = new AppError('ID no válido', 400)
  } else if (!(err instanceof AppError)) {
    error = new AppError('Error interno del servidor', 500)
  }

  res.status(error.statusCode || 500).json({
    success: false,
    message: error.message,
    // Solo incluir stack en desarrollo
    ...(process.env.NODE_ENV === 'development' && { stack: error.stack }),
  })
}

export default errorMiddleware